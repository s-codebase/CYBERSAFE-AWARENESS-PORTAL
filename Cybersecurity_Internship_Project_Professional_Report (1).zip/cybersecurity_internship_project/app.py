"""
CyberSafe Awareness Portal
A beginner-friendly cybersecurity internship project built with Flask.
Educational demo only: it does not scan networks, collect credentials, or run offensive actions.
"""
from flask import Flask, render_template, request, redirect, url_for, flash
import re
from urllib.parse import urlparse

app = Flask(__name__)
app.secret_key = "change-this-demo-secret-key"

QUIZ = [
    {
        "question": "Which action is safest when you receive an unexpected email attachment?",
        "options": ["Open it to check", "Verify the sender and report it if suspicious", "Forward it to everyone"],
        "answer": 1,
        "explanation": "Unexpected attachments can contain malware. Verify the sender through a trusted channel."
    },
    {
        "question": "What makes a password stronger?",
        "options": ["Using your name", "Reusing one password everywhere", "Using a long, unique passphrase"],
        "answer": 2,
        "explanation": "Long, unique passwords or passphrases reduce the risk of account compromise."
    },
    {
        "question": "What should you do before clicking a link in a message?",
        "options": ["Check the destination and context", "Trust it if there is a logo", "Enter your password immediately"],
        "answer": 0,
        "explanation": "Check the sender, message context, and destination carefully. Logos can be copied."
    },
    {
        "question": "Why are software updates important?",
        "options": ["They only change colours", "They can fix known security vulnerabilities", "They disable all security risks forever"],
        "answer": 1,
        "explanation": "Updates often patch vulnerabilities, though safe practices are still needed."
    },
    {
        "question": "Which is a good response to a suspected account compromise?",
        "options": ["Ignore it", "Share the password with a friend", "Use a trusted device to change the password and enable MFA"],
        "answer": 2,
        "explanation": "Secure the account from a trusted device, enable MFA, and follow the service's recovery guidance."
    }
]

CHECKLIST = [
    ("Use unique passwords", "Use a password manager to create and store unique passwords."),
    ("Enable multi-factor authentication", "Add another verification step to important accounts."),
    ("Update devices and apps", "Install updates from official sources."),
    ("Back up important files", "Keep a backup and test that files can be restored."),
    ("Think before clicking", "Verify unexpected links, attachments, and urgent requests."),
    ("Secure Wi-Fi", "Change default router credentials and use modern Wi-Fi security."),
    ("Review app permissions", "Remove access that apps no longer need."),
    ("Know how to report incidents", "Record what happened and contact the appropriate support team.")
]

def password_feedback(password):
    """Return a simple local password-strength estimate; password is never stored."""
    score = 0
    tips = []
    if len(password) >= 12:
        score += 1
    else:
        tips.append("Use at least 12 characters.")
    if re.search(r"[a-z]", password) and re.search(r"[A-Z]", password):
        score += 1
    else:
        tips.append("Mix uppercase and lowercase letters.")
    if re.search(r"\d", password):
        score += 1
    else:
        tips.append("Include a number.")
    if re.search(r"[^A-Za-z0-9]", password):
        score += 1
    else:
        tips.append("Include a symbol.")
    common = {"password", "password123", "123456789", "qwerty", "admin123"}
    if password.lower() in common:
        score = 0
        tips.append("Avoid common passwords.")
    label = ["Very weak", "Weak", "Fair", "Good", "Strong"][score]
    return label, tips

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/password-checker", methods=["GET", "POST"])
def password_checker():
    result = None
    tips = []
    if request.method == "POST":
        password = request.form.get("password", "")
        if not password:
            flash("Enter a sample password to receive feedback.", "warning")
        else:
            result, tips = password_feedback(password)
            # Do not log or persist the supplied password.
    return render_template("password_checker.html", result=result, tips=tips)

@app.route("/url-safety", methods=["GET", "POST"])
def url_safety():
    result = None
    details = []
    if request.method == "POST":
        raw_url = request.form.get("url", "").strip()
        candidate = raw_url if "://" in raw_url else "https://" + raw_url
        parsed = urlparse(candidate)
        host = parsed.hostname or ""
        if not raw_url or not host:
            result = "Unable to assess"
            details.append("Enter a valid-looking domain or URL.")
        else:
            flags = []
            if parsed.scheme != "https":
                flags.append("The URL does not use HTTPS.")
            if "@" in parsed.netloc:
                flags.append("The address contains an @ symbol, which can be used to mislead readers.")
            if host.replace(".", "").isdigit():
                flags.append("The host appears to be an IP address.")
            if host.startswith("xn--") or ".xn--" in host:
                flags.append("The domain uses an internationalized/punycode label.")
            if len(host) > 60:
                flags.append("The hostname is unusually long.")
            if len(re.findall(r"\d", host)) >= 4:
                flags.append("The hostname contains several digits.")
            if flags:
                result = "Review carefully"
                details.extend(flags)
            else:
                result = "No obvious warning found"
                details.append("This basic check did not detect common visual warning signs.")
        details.append("This is a heuristic demo, not a reputation check. A URL may still be malicious.")
    return render_template("url_safety.html", result=result, details=details)

@app.route("/checklist")
def checklist():
    return render_template("checklist.html", items=CHECKLIST)

@app.route("/quiz", methods=["GET", "POST"])
def quiz():
    score = None
    answers = []
    if request.method == "POST":
        for i, question in enumerate(QUIZ):
            try:
                chosen = int(request.form.get(f"q{i}", "-1"))
            except ValueError:
                chosen = -1
            correct = chosen == question["answer"]
            score += 1 if correct else 0
            answers.append({"correct": correct, "explanation": question["explanation"]})
    return render_template("quiz.html", questions=QUIZ, score=score, answers=answers)

@app.route("/about")
def about():
    return render_template("about.html")

@app.errorhandler(404)
def not_found(_error):
    return render_template("404.html"), 404

if __name__ == "__main__":
    app.run(debug=True)
