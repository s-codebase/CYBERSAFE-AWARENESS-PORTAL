# CyberSafe Awareness Portal

A beginner-friendly cybersecurity awareness website suitable for a cybersecurity internship mini-project. It demonstrates secure-awareness concepts using a password-strength feedback tool, a basic URL warning-sign checker, a safety checklist, and a short quiz.

## Features
- Responsive homepage and navigation
- Password strength feedback (input is processed locally by the app and is not saved)
- Basic URL warning-sign checker (heuristic only; not a malware/reputation scanner)
- Cybersecurity best-practice checklist
- Five-question awareness quiz with explanations
- Flask routes and HTML templates

## Technology
- Python 3.10+
- Flask
- HTML5 and CSS3

## Project structure
```text
cybersecurity_internship_project/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── password_checker.html
│   ├── url_safety.html
│   ├── checklist.html
│   ├── quiz.html
│   ├── about.html
│   └── 404.html
├── static/
│   └── style.css
└── reports/
    ├── Project_Report.md
    └── Project_Report.pdf
```

## Setup and run

### 1. Install Python
Install Python 3.10 or later. During installation on Windows, enable **Add Python to PATH**.

### 2. Open the project folder
Open Terminal / Command Prompt in this folder.

### 3. Create and activate a virtual environment (recommended)
Windows:
```powershell
python -m venv .venv
.venv\Scripts\activate
```
macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 4. Install dependencies
```bash
python -m pip install -r requirements.txt
```

### 5. Start the website
```bash
python app.py
```
Open `http://127.0.0.1:5000` in your browser. Stop the server with `Ctrl+C`.

## Important limitations and safety
- This is an educational awareness project, not a penetration-testing tool.
- The password checker gives simple complexity feedback only. Do not enter real passwords; use sample values.
- The URL checker does not contact the website, follow redirects, or query threat-intelligence services. “No obvious warning found” does **not** mean a URL is safe.
- The Flask development server is for local demonstration only. Do not deploy it publicly with debug mode enabled.
- Before any real deployment, use a secure random secret key, production WSGI server, HTTPS, security headers, input validation, logging policy, and appropriate privacy review.

## Suggested demonstration
1. Show the home page.
2. Test a sample password such as `Example-Strong-Password-42!` (do not use a real password).
3. Compare a plain domain and a suspicious-looking sample URL in the URL checker.
4. Review the checklist.
5. Complete the quiz and explain the answers.

## Author details
A professionally formatted PDF report is available at `reports/Project_Report.pdf`; the Markdown version is editable at `reports/Project_Report.md`.

Replace the placeholders in the project report with your name, institution, internship organization, supervisor, and submission date before submitting.
